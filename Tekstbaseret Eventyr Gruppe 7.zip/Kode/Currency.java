public class Currency extends Inventory {
}
